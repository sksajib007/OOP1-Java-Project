package Interface;
import java.lang.*;
import Class.*;

public interface IQuantity{
	
	void addQuantity(int amount);
	void sellQuantity(int amount);
}